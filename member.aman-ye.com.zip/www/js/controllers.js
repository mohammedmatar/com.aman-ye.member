angular.module('app.controllers', [])
  
.controller('mainCtrl', function($scope) {

})
   
.controller('updateCtrl', function($scope) {

})
 